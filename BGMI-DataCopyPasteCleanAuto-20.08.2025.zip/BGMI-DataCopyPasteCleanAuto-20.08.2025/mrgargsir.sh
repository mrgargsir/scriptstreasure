#!/system/bin/sh
BASEDIR=$(dirname "$0")
DEX="$BASEDIR"/rish_shizuku.dex

# Output UI messages
YELLOW='\033[1;33m'
RED='\033[1;31m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
GREEN='\033[1;32m'
RESET='\033[0m'

echo -e "${YELLOW}✨ Script by MRGARGSIR — Stay Safe & Have Fun! ✨${RESET}"
echo -e "${RED}📢 Telegram Group: @BabaDangerYT${RESET}"
echo -e "${BLUE}📬 Reach out: @MRGARGSIR on Telegram/Instagram${RESET}"

if [ ! -f "$DEX" ]; then
  echo "Cannot find $DEX, please check the tutorial in Shizuku app"
  exit 1
fi

if [ $(getprop ro.build.version.sdk) -ge 34 ]; then
  if [ -w $DEX ]; then
    echo "On Android 14+, app_process cannot load writable dex."
    echo "Attempting to remove the write permission..."
    chmod 400 $DEX
  fi
  if [ -w $DEX ]; then
    echo "Cannot remove the write permission of $DEX."
    echo "You can copy to file to terminal app's private directory (/data/data/<package>, so that remove write permission is possible"
    exit 1
  fi
fi

all="$BASEDIR"/DataCopyPasteClean-mrgargsir.sh
    chmod +x "$all"
    echo -e "${YELLOW}🚨 Due to Android restrictions, please manually type anyone command from the following :${RESET}"
    echo -e ""
echo -e "${GREEN}sh all${RESET}"
echo -e "${GREEN}sh temp${RESET}"

# Replace "PKG" with the application id of your terminal app
[ -z "$RISH_APPLICATION_ID" ] && export RISH_APPLICATION_ID="bin.mt.plus"
/system/bin/app_process -Djava.class.path="$DEX" /system/bin --nice-name=rish rikka.shizuku.shell.ShizukuShellLoader "$@"  

sh all