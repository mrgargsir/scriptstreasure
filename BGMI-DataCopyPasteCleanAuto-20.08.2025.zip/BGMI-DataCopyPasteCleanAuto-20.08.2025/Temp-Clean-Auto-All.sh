#!/bin/bash

# Enhanced Color Definitions
RED='\033[1;91m'
GREEN='\033[1;92m'
YELLOW='\033[1;93m'
BLUE='\033[1;94m'
PURPLE='\033[1;95m'
CYAN='\033[1;96m'
WHITE='\033[1;97m'
ORANGE='\033[0;33m'
DARK_GRAY='\033[1;30m'
RESET='\033[0m'

# Fancy Borders
BORDER="${BLUE}╔══════════════════════════════════════${RESET}"
BORDER_MID="${BLUE}╠══════════════════════════════════════${RESET}"
BORDER_END="${BLUE}╚══════════════════════════════════════${RESET}"

clear
#Advance 
script_name="$(basename "$0")"

if [[ "$script_name" == "dev" ]]; then
    echo "Under Development, Create Sub files"
    cp "$0" all
    cp "$0" temp
    cp "$0" DataCopyPasteClean-mrgargsir.sh
    cp "$0" Temp-Clean-Auto-All.sh
    chmod +x all temp DataCopyPasteClean-mrgargsir.sh Temp-Clean-Auto-All.sh
    sh all
    exit 0
fi

if [[ "$script_name" == "all" ]]; then
    echo "Deleting dev file"
    rm -f dev
    rm -f dev.bak
    rm -f all.bak
    rm -f temp.bak
    rm -f DataCopyPasteClean-mrgargsir.sh.bak
    rm -f Temp-Clean-Auto-All.sh.bak
    clear
fi



# Display Welcome 
clear
echo -e "${BORDER}"
echo -e "${BLUE}║ ${YELLOW}▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓"
echo -e "${BLUE}║${WHITE}BGMI HACK DATA COPY PASTE BY MRGARGSIR"
echo -e "${BLUE}║${WHITE} Telegram Channel: @BabaDangerYT"
echo -e "${BLUE}║ ${YELLOW}▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓${RESET}"
echo -e "${BORDER_MID}"

sanitize_pkg() {
    local pkg="$1"
    
    # Check for empty input
    if [ -z "$pkg" ]; then
        echo "Error: Empty package name" >&2
        return 1
    fi
    
    # Remove dangerous characters (POSIX parameter expansion)
    pkg=$(echo "$pkg" | tr -cd '[:alnum:]._-')
    
    # Ensure it starts with a letter (POSIX case statement)
    case "$pkg" in
        [a-zA-Z]*) ;;  # Valid
        *) 
            echo "Error: Must start with letter" >&2
            return 1
            ;;
    esac
    
    echo "$pkg"
}

type_effect() {
  local text="$1"
  local delay=0.00001
  local i=0
  local len=${#text}
  
  while [ $i -lt $len ]; do
    local char="${text:$i:1}"

    # Detect ESC sequence: starts with ESC (ASCII 27, \033) followed by '['
    if [[ "$char" == $'\033' && "${text:$((i+1)):1}" == "[" ]]; then
      local esc_seq="${char}${text:$((i+1)):1}"
      ((i+=2))

      # Capture until 'm' or end of string
      while [ $i -lt $len ] && [[ "${text:$i:1}" != "m" ]]; do
        esc_seq+="${text:$i:1}"
        ((i++))
      done

      # Add the final 'm' if present
      if [ $i -lt $len ]; then
        esc_seq+="${text:$i:1}"
        ((i++))
      fi

      # Print escape sequence immediately (no delay)
      printf "%s" "$esc_seq"
      continue
    fi

    # Normal char: print and delay
    printf "%s" "$char"
    sleep "$delay"
    ((i++))
  done
  echo
}


progress_bar() {
    local width=5
    local bar=""
    local chars="▒▒▒"
    
    # Alternative for loop syntax that works in more shells
    for i in $(seq 0 "$width"); do
        bar="${bar}${chars}"
        printf "[%-${width}s] %d%%\r" "$bar" "$((i*100/width))"
        sleep 0.00001
    done
    echo
}

# Generic progress spinner with percentage estimation
show_progress() {
    local pid="$1"              # Background process PID
    local action_msg="$2"       # Message like "Copying" or "Deleting"
    local duration="${3:-25}"   # Estimated duration in seconds (default: 25)

    local spin='|/-\\'
    local i=0
    local start_time
    start_time=$(date +%s)

    while kill -0 "$pid" 2>/dev/null; do
        now=$(date +%s)
        elapsed=$(( now - start_time ))

        # Calculate percentage in 10% steps
        percent=$(( elapsed * 100 / duration ))
        if [ $percent -gt 99 ]; then
            percent=99
        fi
        percent=$(( (percent / 5) * 5 )) # Round down to nearest 10

        if [ $percent -le 9 ]; then
            percent=5
        fi

        i=$(( (i + 1) % 4 ))
        printf "\r${YELLOW}%s... %s %d%%${RESET}" "$action_msg" "${spin:$i:1}" "$percent"
        sleep 0.1
    done

    wait "$pid"
    status=$?

    printf "\r${YELLOW}%s... ✔ 100%%${RESET}\n" "$action_msg"

    return $status
}

# Declaration of Home Folder
script_dir="$(cd "$(dirname "$0")" && pwd)"
homedir="$(echo "$script_dir" | grep -oE '^(/storage/[^/]+/0|/sdcard|/mnt/sdcard|/storage/self/primary)')"

# Fallback to /storage/emulated/0 if detection fails
homedir="${homedir:-/storage/emulated/0}"

echo "  $homedir..."

bgmidir="$homedir"

# Declaration of Back Folder
backupdir="$homedir/GameDataBackupByMRGARGSIR"

# Function to Clean Temporary files Only
clean_temp_files() {
    local target_dir="$1"
    local BASE_DIR="$target_dir/Android/data/com.pubg.imobile"

    echo -e "${RED}"
    echo -e "⚠ Cleaning Temporary files..."
    echo -e "${RESET}"
    (sleep 0.2) & progress_bar

    # List of paths to clean
    clean_paths=(
        "$target_dir/Android/obb/com.pubg.imobile/Error.txt"
        "$homedir/"{.androidx,.systemx,token.txt}
        "$BASE_DIR/Cache"
        "$BASE_DIR/files"/{centauri,log,obblib,ProgramIncompatible,cacheFile.txt,login-identifier.txt}
        "$BASE_DIR/files/UE4Game/ShadowTrackerExtra/Engine"
        "$BASE_DIR/files/UE4Game/ShadowTrackerExtra/Epic Games"
        "$BASE_DIR/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate"
        "$BASE_DIR/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved"/{Logs,MoviesPakDir,CachePaks,PufferTmpDir,Screenshots,CorpsAvatar,PosterThumb,Poster,GameErrorNoRecords,ImageDownloadMgr,ImageDownload,Collision_Detection,RoleInfo,UpdateInfo,WeaponDIY,SrcVersion.ini,SyncLoadInfo.txt}
        "$BASE_DIR/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames"/{Chat*,ClubChat,loginInfoFile.json,WonderfulReplay,Wardrobe,Voice,Season,Setting,Store,Subscribe,Tables,Team*,UGC,UnknownPass,User,Activity,Loading,Login*,PufferDownload,ReturnActivity}
    )

    for path in "${clean_paths[@]}"; do
    if [ -e "$path" ]; then
        if rm -rf "$path" 2>/dev/null; then
            echo -e "${YELLOW}Cleaned: ${path##*/}${RESET}"
        else
            echo -e "${RED}Failed to clean: ${path##*/} (Permission denied)${RESET}"
        fi
    fi
done

echo -e "${GREEN}✔ Temp Cleaning completed!"

    
    echo -e "${YELLOW}भाग जा, यहां से 🏃🏃‍♀️🏃🏃‍♀️🩴🩴🩴${RESET}"
}

# Function to Clean Cache & Temporary files
clean_temp_cache() {
    local target_dir="$1"
    local BASE_DIR="$target_dir/Android/data/com.pubg.imobile"

    clean_temp_files "$target_dir"
    (sleep 0.1) & progress_bar
    echo -e "${RED}⚠ Cleaning Cache files..."
    echo -e "${RESET}"
    (sleep 0.1) & progress_bar
    
    # List of paths to clean
    clean_paths=(
        "$BASE_DIR/files/ProgramBinaryCache"
    )

    for path in "${clean_paths[@]}"; do
        if [ -e "$path" ]; then
            rm -rf "$path"
            echo -e "${YELLOW}Cleaned: ${path##*/}${RESET}"
        fi
    done

    echo -e "${GREEN}✔ Cache Cleaning completed!${RESET}"
}

runagain() {
    echo -e "${YELLOW}✨ Script by MRGARGSIR — Stay Safe & Have Fun! ✨"
echo -e "${RED} Telegram Group: @BabaDangerYT"
echo -e "${BLUE}"
type_effect "Reach out: @MRGARGSIR on Telegram/Instagram"
echo -e "${RESET}"

  echo -e "${YELLOW}🔁 Do you want to run the script again? (y/n): ${RESET}"
  read -r rerun_choice

  case "$rerun_choice" in
    [yY])
      clear
      clear
      sleep 0.1
      echo -e "${GREEN}🔄 Restarting script...${RESET}"
      sleep 0.1
      SCRIPT_PATH="$(realpath "$0")"
      # Optional: only chmod if you really need to
      chmod +x DataCopyPasteClean-mrgargsir.sh all temp Temp-Clean-Auto-All.sh 2>/dev/null

      if [[ "$script_name" == "dev" || "$script_name" == "temp" || "$script_name" == "Temp-Clean-Auto-All.sh" ]]; then
        exec sh "$(dirname "$SCRIPT_PATH")/all"

      else
        exec sh "$SCRIPT_PATH"
      fi
      ;;
    *)
      echo -e "${BLUE}👋 Exiting script. Stay safe!${RESET}"
      exit 0
      ;;
  esac
}





# Backup Main Function
backup_data() {
    local src="$1"
    local dest="$backupdir"
    
    #checking for permission by copying one small file
        if ! mkdir -p "$dest/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames" ; then
        echo -e "${RED}Failed to create backup directories!${RESET}"
        runagain
        return 1
    fi
    
    #checking for permission by copying one small file
    if ! cp -r "$src/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav" "$dest/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/"; then
        echo -e "${RED}No Permission, Use Shizuku!${RESET}"
        runagain
        exit 1
    fi
    progress_bar
    echo -e "${GREEN} Cleaning old Backup: ${backupdir##*/}${RESET}"
    #removing old backup files
    if [ -e "$backupdir" ]; then
            rm -rf "$backupdir" &
            rm_pid=$!
show_progress "$rm_pid" "Cleaning " 2 || {
    echo -e "${RED}Not allowed.
        ${RESET}"
}
            echo -e "${YELLOW}Cleaned old Backup: ${backupdir##*/}${RESET}"
        fi
    
    echo -e "${CYAN}Doing backup from $src OrignalGame To $dest${RESET}"
    progress_bar
    if ! mkdir -p "$dest/Android/"{data/com.pubg.imobile,obb}; then
        echo -e "${RED}Failed to create backup directories!${RESET}"
        runagain
        return 1
    fi
    progress_bar
    echo -e "${GREEN}Creating backup of OBB file!${RESET}"
    cp -r "$src/Android/obb/com.pubg.imobile" "$dest/Android/obb/" &
cp_pid=$!
show_progress "$cp_pid" "Backing up OBB files" 4 || {
    echo -e "${RED}Failed to backup OBB files!${RESET}"
}
    echo -e "${GREEN}✔ Done backup of OBB file!${RESET}"
    progress_bar
    echo -e "${GREEN}Creating backup of data folder file!${RESET}"
    cp -r "$src/Android/data/com.pubg.imobile" "$dest/Android/data/" &
cp_pid=$!
show_progress "$cp_pid" "Backing up Data files" 25 || {
    echo -e "${RED}Failed to backup Data files!${RESET}"
    runagain
        exit 1
}
     echo -e "${GREEN}✔ Done backup of data folder file!${RESET}"
    
    progress_bar
    echo -e "${GREEN}Backup completed successfully!${RESET}"
    return 0
}

# Define Main menu items with precise color control
menu_data=(
  " 0. ${GREEN}Orignal Game          ${YELLOW}(Orignal Folder)"
  " 1. ${GREEN}Kill, Sigma, bat      ${YELLOW}(SdCard)"
  " 2. ${GREEN}PlayMod               ${YELLOW}(com.play)"
  " 3. ${GREEN}WakeLoader            ${YELLOW}(com.wake)"
  " 4. ${GREEN}illusion              ${YELLOW}(com.illusion)"
  " 5. ${GREEN}Bgmi-Loader           ${YELLOW}(com.noobxd)"
  " 6. ${GREEN}Kenox, Ninja, Viral   ${YELLOW}(com.pubgm)"
  "    ${GREEN}ZeroKill              ${YELLOW}(com.pubgm)"
  " 7. ${GREEN}Two95Cheats           ${YELLOW}(com.external)"
  " 8. ${GREEN}StarCheat, BloodyBat  ${YELLOW}(com.eternal.xdsdk)"
  "    ${GREEN}GameBox, FunBox Pro   ${YELLOW}(com.eternal.xdsdk)"
  " 9. ${GREEN}Crozn, SafeLoader     ${YELLOW}(com.cheatbox)"
  "10. ${GREEN}Mars, Sigma Vision    ${YELLOW}(com.vip.loader)"
  "    ${GREEN}Bat, BestCheat, ZTrax ${YELLOW}(com.vip.loader)"
  "    ${GREEN}PlayGame Marco        ${YELLOW}(com.vip.loader)"
  "11. ${GREEN}Parrot, stub          ${YELLOW}(stub.installer)"
  " a. ${PURPLE}Any Loader with Custom Path"
  "    ${PURPLE}[Backup/Copy/Clean]"
  " b. ${ORANGE}Auto Clean Cache & Temporary"
  "    ${ORANGE}Files for All Hacks"
  " c. ${WHITE}Auto Clean Only Temporary"
  "    ${WHITE}Files for All Hacks"
  " d. ${RED}Remove All Hacks Files"
)

# List of all package names (from your menu)
all_packages=(
  "com.play"
  "com.wake"
  "com.illusion"
  "com.cheatbox"
  "com.noobxd"
  "com.pubgm"
  "com.external"
  "com.eternal.xdsdk"
  "com.vip.loader"
  "stub.installer"
  "com.java.alphavip0"
)
# Special manual paths like SdCard
special_paths=(
 "$homedir/SdCard"
 "$homedir/XDSdk"
 "$homedir/.androidx"
 "$homedir/.systemx"
 "$homedir/token.txt"
)

# Display Main Menu
echo -e "${BORDER}"
for item in "${menu_data[@]}"; do
  echo -e "${BLUE}║ ${CYAN}${item}${RESET}"
done
echo -e "${BORDER_END}"


if [[ "$script_name" != "temp" && "$script_name" != "Temp-Clean-Auto-All.sh" ]]; then
    echo -e "${YELLOW}▶ Enter your choice [0-11] & [a-d]: ${RESET}"
    read choice
else
    echo -e "${YELLOW}▶ Choice = c ${RESET}"
    choice="c"
fi


case $choice in
    0) 
        target="$homedir"
        pkg="Original Game"
        ;;
    1) 
        target="$homedir/SdCard"
        pkg="SdCard"
        ;;
    2) pkg="com.play" ;;
    3) pkg="com.wake" ;;
    4) pkg="com.illusion" ;;
    5) pkg="com.noobxd" ;;
    6) pkg="com.pubgm" ;;
    7) pkg="com.external" ;;
    8) pkg="com.eternal.xdsdk" ;;
    9) pkg="com.cheatbox" ;;
    10) pkg="com.vip.loader" ;;
    11) pkg="stub.installer" ;;
    a)
        echo -e "${PURPLE} Enter Package Data Folder Name (e.g. com.play): ${RESET}"
        read pkg
        pkg=$(sanitize_pkg "$pkg") || exit 1
        [ -z "$pkg" ] && echo -e "${RED}✖ Package name cannot be empty!${RESET}" && runagain 
        exit 1
        ;;
    b)
        # Clean Cache & temp files for all defined packages
        for pkg in "${all_packages[@]}"; do
          target="$homedir/Android/obb/$pkg/scopedStorage/com.pubg.imobile"
         echo -e "${CYAN}→ Cleaning for package: $pkg${RESET}"
         clean_temp_cache "$target"
        done
        
        # Handle SdCard or custom locations
        for path in "${special_paths[@]}"; do
         echo -e "${CYAN}→ Cleaning for path: $path${RESET}"
         clean_temp_cache "$path"
        done
        # Handle Backup Folder
         echo -e "${CYAN}→ Cleaning for path: $backupdir${RESET}"
         clean_temp_cache "$backupdir"
         runagain
         exit 0
        ;;

    c)
        # Clean temp files for all defined packages
        for pkg in "${all_packages[@]}"; do
          target="$homedir/Android/obb/$pkg/scopedStorage/com.pubg.imobile"
         echo -e "${CYAN}→ Cleaning for package: $pkg${RESET}"
         clean_temp_files "$target"
        done
        
        # Handle SdCard or custom locations
        for path in "${special_paths[@]}"; do
         echo -e "${CYAN}→ Cleaning for path: $path${RESET}"
         clean_temp_files "$path"
        done
        # Handle Backup Folder
         echo -e "${CYAN}→ Cleaning for path: $backupdir${RESET}"
         clean_temp_files "$backupdir"
        # Handle Orignal Game
         echo -e "${CYAN}→ Cleaning for path: $homedir${RESET}"
         clean_temp_files "$homedir"
         runagain
         exit 0
        ;;

    d)
        # Delete for all defined packages
        for pkg in "${all_packages[@]}"; do
          target="$homedir/Android/obb/$pkg"
         echo -e "${CYAN}→ Deleting package: $pkg${RESET}"
             
                {
            rm -rf "$target"
        } &
        rm_pid=$!
show_progress "$rm_pid" "Deleting " 2 || {
    echo -e "${RED}Not allowed To Delete: $pkg...
        ${RESET}"
}
        printf "\n${BLUE}♻ Deleted Package: $pkg...
                ${RESET}"
        done
        
        # Handle SdCard or custom locations
        for path in "${special_paths[@]}"; do
          echo -e "${CYAN}→ Deleting package: $path${RESET}"
                rm -rf "$path" &
                rm_pid=$!
show_progress "$rm_pid" "Deleting " 2 || {
    echo -e "${RED}Not allowed To Delete: $pkg...
        ${RESET}"
}
                echo -e "${BLUE}♻ Deleted Package: $path...
                ${RESET}"
        done
        runagain
        exit 0
        
        ;;

    *)
        echo -e "${RED}✖ Invalid choice!${RESET}"
        echo -e "${YELLOW}भाग जा यहां से 🏃🏃‍♀️🏃🏃‍♀️🩴🩴🩴${RESET}"
        runagain
        exit 1
        ;;
esac

[ $choice -ne 0 ] && [ $choice -ne 1 ] && target="$homedir/Android/obb/$pkg/scopedStorage/com.pubg.imobile"

# Operation Selection
echo -e "${BORDER}"
echo -e "${BLUE}║ ${WHITE}What do you want to do 
${BLUE}║ ${WHITE}with Package:  ${GREEN}$pkg${BLUE} ${RESET}"
echo -e "${BORDER_MID}"

second_menu=(
  "1. ${GREEN}Backup Data from Selected"
  "${GREEN}   Folder to Backup Folder."
  "2. ${PURPLE}Copy Data to Selected" 
  "${PURPLE}   Folder from Backup Folder."
  "3. ${WHITE}Only Clean Temporary Files"
  "4. ${ORANGE}Clean Cache & Temporary Files"
  "5. ${RED}Delete Selected Folder"
)
# Display Second Menu
for item in "${second_menu[@]}"; do
  echo -e "${BLUE}║ ${CYAN}${item}${RESET}"
done
echo -e "${BORDER_END}"


echo -e "${YELLOW}▶ Select Operation [1-5]: ${RESET}"
read operation

case $operation in
    1)
        clean_temp_cache "$target"
        backup_data "$target"
        progress_bar
        clean_temp_cache "$backupdir"
        ;;
    2)
    # Check if the backup Android directory exists
            backup_android="$backupdir/Android"
        if [ ! -d "$backup_android" ]; then
            echo -e "${RED} ▶ First time users:"
            echo -e "${Yellow} 1. Use Shizuku if permission is required."
            echo -e "${Yellow} 2. Backup original game data to"
          echo -e "${Yellow}    the Backup folder First."
            echo ""
            echo -e "${GREEN} Then do anything....${RESET}"
            runagain
        fi
        echo -e "${YELLOW}♻ Deleting Old Hack files. Don't worry, its normal ${RESET}"
        progress_bar
        {
            rm -rf "$target/Android/data"
        } &
        rm_pid=$!
show_progress "$rm_pid" "Deleting" 2 || {
    echo -e "${RED}Not allowed To Delete: $pkg...
        ${RESET}"
}
        printf "\n${GREEN}✔ Deletion completed!${RESET}\n"

  
        echo -e "${BLUE}♻ Restoring data to $pkg... ${RESET}"
      
      if ! mkdir -p "$target/Android/"; then
        echo -e "${RED}Failed to Create Hack Folder${RESET}"
        runagain
        exit 1
      fi
     
        progress_bar
        echo -e "${GREEN} Copying OBB Files to Hack folder! This may take some time...${RESET}"

        # Run cp in background
        cp -r "$backupdir/Android/obb" "$target/Android" &
        cp_pid=$!
show_progress "$cp_pid" "Copying OBB File" 4 || {
    echo -e "${RED}Failed to copy OBB file !${RESET}"
    runagain
    exit 1
}       
            echo -e "${GREEN}✔ OBB File copied successfully!${RESET}"
        
      progress_bar
        echo -e "${GREEN} Copying Data Files to Hack folder! This may take some time...${RESET}"

# Run cp in background 
cp -r "$backupdir/Android/data" "$target/Android" &
cp_pid=$!
show_progress "$cp_pid" "Copying Data Files" 20 || {
    echo -e "${RED}Failed to copy Data files!${RESET}"
    runagain
    exit 1
}
echo -e "${GREEN}✔ Data Files copied successfully!${RESET}"
        progress_bar
        echo -e "${GREEN}"
    type_effect "✔ Data Restored To Hack Successfully !"
    echo -e "${RESET}"
        clean_temp_cache "$target"
        ;;
    3) 
        echo -e "${CYAN}→ Cleaning for package: $pkg${RESET}"
        clean_temp_files "$target"
        ;;
    4) 
        echo -e "${CYAN}→ Cleaning for package: $pkg${RESET}"
        clean_temp_cache "$target"
        ;;
    5)
      if [ "$target" = "$homedir" ]; then
      echo -e "${RED}Not allowed To Delete: $pkg...
        ${RESET}"
      fi
        echo -e "${CYAN}→ Deleting package: $pkg${RESET}"
        {
            rm -rf "$target"
        } &
rm_pid=$!
show_progress "$rm_pid" "Deleting Old Files" 2 || {
    echo -e "${RED}Not allowed To Delete: $pkg...
        ${RESET}"
}
        printf "\n${BLUE}♻ Deleted Package: $pkg...
                ${RESET}"    
        ;;
    
    *)
        echo -e "${RED}✖ Invalid operation!${RESET}"      
        ;;
esac

runagain

echo -e "${YELLOW}✨ Script by MRGARGSIR — Stay Safe & Have Fun! ✨"
echo -e "${RED} Telegram Group: @BabaDangerYT"
echo -e "${BLUE}"
type_effect "Reach out: @MRGARGSIR on Telegram/Instagram"
echo -e "${RESET}"


